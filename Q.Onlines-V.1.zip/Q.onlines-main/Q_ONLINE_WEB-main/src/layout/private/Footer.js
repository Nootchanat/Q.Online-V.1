import React from 'react';

function Footer() {
  return (
    <footer id="private">
    <div className="footer">
      <span>Created By HUGCODE CO.,LTD.</span>
    </div>
  </footer>
  );
}

export default Footer;
