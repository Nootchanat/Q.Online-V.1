import { combineReducers } from 'redux';
import Authentication from './Authentication';

export default combineReducers({
  Authentication: Authentication,
});
